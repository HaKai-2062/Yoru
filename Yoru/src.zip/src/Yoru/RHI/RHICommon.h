#pragma once
#include <cstdint>

struct InstanceDesc
{
	bool EnableValidationLayers = false;
	void* NativeWindow = nullptr;
};

struct DeviceDesc
{
	bool PreferDiscreteGPU = true;
};

struct SwapchainDesc
{
	uint32_t Width = 0;
	uint32_t Height = 0;
	bool VSync = false;
};

struct RendererDesc
{
	InstanceDesc InstDesc;
	DeviceDesc DeviceDesc;
	SwapchainDesc SwapchainDesc;
};