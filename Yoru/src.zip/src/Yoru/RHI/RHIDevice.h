#pragma once

#include "Yoru/RHI/RHICommon.h"

namespace Yoru
{
	class RHIInstance;
	class RHISwapchain;
	class RHIDevice
	{
	public:
		RHIDevice() = default;
		virtual ~RHIDevice() = default;

		virtual bool Init(const DeviceDesc& desc) = 0;
		virtual void Shutdown() = 0;

		virtual RHISwapchain* CreateSwapchain(const SwapchainDesc& desc) = 0;
	};
}
