#pragma once

#include "Yoru/RHI/RHICommon.h"
#include "Yoru/RHI/RHIInstance.h"
#include "Yoru/RHI/RHIDevice.h"
#include "Yoru/RHI/RHISwapchain.h"

namespace Yoru
{
	class RHIRenderer
	{
	public:
		RHIRenderer() = default;
		virtual ~RHIRenderer() = default;
	
		virtual bool Init(const RendererDesc& desc) = 0;
		virtual void Shutdown() = 0;
	
		virtual void BeginFrame() = 0;
		virtual void EndFrame() = 0;

	protected:
		std::unique_ptr<RHIInstance> m_Instance;
		std::unique_ptr<RHIDevice> m_Device;
		std::unique_ptr<RHISwapchain> m_Swapchain;
	};
}