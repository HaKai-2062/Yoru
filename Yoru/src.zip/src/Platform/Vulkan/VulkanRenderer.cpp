#include "Platform/Vulkan/VulkanRenderer.h"
#include "Platform/Vulkan/VulkanInstance.h"
#include "Platform/Vulkan/VulkanSwapchain.h"

namespace Yoru
{
	bool VulkanRenderer::Init(const RendererDesc& desc)
	{
		Log::Write(LogLevel::INFO, "{}: Init", m_ClassName);

		m_Instance = std::unique_ptr<RHIInstance>(CreateInstance(desc.InstDesc));
		if (!m_Instance) return false;
		m_VulkanInstance = static_cast<VulkanInstance*>(m_Instance.get());

		m_Device = std::unique_ptr<RHIDevice>(m_Instance->CreateDevice(desc.DeviceDesc));
		if (!m_Device) return false;
		m_VulkanDevice = static_cast<VulkanDevice*>(m_Device.get());

		m_Swapchain = std::unique_ptr<RHISwapchain>(m_Device->CreateSwapchain(desc.SwapchainDesc));
		if (!m_Swapchain) return false;
		m_VulkanSwapchain = static_cast<VulkanSwapchain*>(m_Swapchain.get());

		m_HasInitialized = true;
		return true;
	}

	void VulkanRenderer::Shutdown()
	{
		if (m_Swapchain)
			m_Swapchain->Shutdown();
		if (m_Device)
			m_Device->Shutdown();
		if (m_Instance)
			m_Instance->Shutdown();

		Log::Write(LogLevel::INFO, "{}: Shutdown", m_ClassName);
	}

	void VulkanRenderer::BeginFrame()
	{

	}

	void VulkanRenderer::EndFrame()
	{

	}

	VulkanInstance* VulkanRenderer::CreateInstance(const InstanceDesc& desc)
	{
		m_VulkanInstance = new VulkanInstance;
		if (m_VulkanInstance->Init(desc))
		{
			return m_VulkanInstance;
		}

		return nullptr;
	}
}