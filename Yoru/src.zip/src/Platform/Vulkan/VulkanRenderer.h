#pragma once

#include "Yoru/RHI/RHICommon.h"
#include "Yoru/RHI/RHIRenderer.h"

namespace Yoru
{
	class VulkanInstance;
	class VulkanDevice;
	class VulkanSwapchain;

	class VulkanRenderer : public RHIRenderer
	{
	public:
		VulkanRenderer() = default;
		~VulkanRenderer() = default;

		virtual bool Init(const RendererDesc& desc) override;
		virtual void Shutdown() override;

		virtual void BeginFrame() override;
		virtual void EndFrame() override;

		VulkanInstance* CreateInstance(const InstanceDesc& desc);

	private:
		static inline const char* m_ClassName = "VulkanRenderer";
		bool m_HasInitialized = false;

		VulkanInstance* m_VulkanInstance = nullptr;
		VulkanDevice* m_VulkanDevice = nullptr;
		VulkanSwapchain* m_VulkanSwapchain = nullptr;
	};
}